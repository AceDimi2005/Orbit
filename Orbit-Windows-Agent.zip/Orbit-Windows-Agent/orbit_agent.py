"""Orbit PC Companion: authenticated local-network monitoring and controls."""
import asyncio
import copy
import ctypes
import hmac
import io
import ipaddress
import json
import logging
import math
import os
import secrets
import socket
import subprocess
import threading
import time
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime
from pathlib import Path

import psutil
import uvicorn
from fastapi import FastAPI, Header, HTTPException, Query, Request, WebSocket, WebSocketDisconnect

from orbit_processes import collect_processes, terminate_process
from orbit_files import create_files_router
from orbit_desktop import create_desktop_router
from orbit_history import SessionRecorder, create_history_router
from orbit_pairing import PairingManager, OrbitAdvertisement, create_pairing_router

from orbit_hardware import (GPU_SENSOR_FIELDS, IOCounterRates, RATE_FIELDS, SENSOR_FIELDS, basic_specs,
                            collect_specs, detect_game, io_metrics, nvidia_metrics,
                            read_fps, sensor_metrics, timestamp)

try:
    import mss
    from PIL import Image
    HAS_SCREEN_CAPTURE = True
except ImportError:
    HAS_SCREEN_CAPTURE = False

try:
    import comtypes
    from pycaw.pycaw import AudioUtilities
    HAS_PYCAW = True
except (ImportError, OSError):
    HAS_PYCAW = False

AGENT_VERSION = "4.1.0"
LOGGER = logging.getLogger("orbit")
API_TOKEN = ""
WIDGET_TOKEN = ""
AGENT_PORT = int(os.getenv("ORBIT_PORT", "8765"))
SECURE_PORT = int(os.getenv("ORBIT_TLS_PORT", "8766"))
PAIRING_MANAGER = None
ADVERTISEMENT = None
CERTIFICATE_FINGERPRINT = ""
import sys as _sys
_RUNTIME_DIR = Path(_sys.executable).resolve().parent if getattr(_sys, "frozen", False) else Path(__file__).resolve().parent
TOKEN_PATH = Path(os.getenv("ORBIT_TOKEN_FILE", str(_RUNTIME_DIR / ".orbit-token")))
WIDGET_TOKEN_PATH = Path(os.getenv("ORBIT_WIDGET_TOKEN_FILE", str(_RUNTIME_DIR / ".orbit-widget-token")))
SUNSHINE_APPS_PATHS = [
    Path(os.getenv("PROGRAMDATA", "C:/ProgramData")) / "LizardByte/Sunshine/config/apps.json",
    Path(os.getenv("PROGRAMFILES", "C:/Program Files")) / "Sunshine/config/apps.json",
    Path.home() / ".config/sunshine/apps.json",
]
if os.getenv("ORBIT_SUNSHINE_APPS"):
    SUNSHINE_APPS_PATHS.insert(0, Path(os.environ["ORBIT_SUNSHINE_APPS"]))

STATE_LOCK = threading.Lock()
STOP_EVENT = threading.Event()
SPECS = {}
SENSOR_GPU_CACHE = {}
STATE = {
    "agentVersion": AGENT_VERSION, "sensorSource": None, "sensorStatus": None, "gpuSource": None,
    "networkInterface": None,
    "hostname": socket.gethostname(), "cpuName": "Unavailable", "motherboard": "Unavailable",
    "coolerName": "Unavailable", "gpuName": "Unavailable", "isOnline": True,
    "cpuTemp": None, "cpuUsage": 0.0, "liquidTemp": None, "gpuTemp": None,
    "gpuUsage": None, "gpuPowerWatts": None, "vramUsedGB": None, "vramTotalGB": None,
    "ramUsedGB": 0.0, "ramTotalGB": 0.0, "ssdUsedTB": 0.0, "ssdTotalTB": 0.0,
    "uptimeSeconds": 0, "activeGame": None, "activeGameProcess": None,
    "volume": 0.0, "isMuted": False, "volumeAvailable": False, "hdrEnabled": None,
    "fps": None, "fpsSource": None, "fpsUnavailableReason": "Waiting for telemetry",
    "telemetryAvailable": False, "lastUpdated": None,
    "cpuPowerWatts": None, "cpuClockMHz": None, "cpuClockSource": None,
    "cpuFanRPM": None, "gpuFanPercent": None,
    "diskReadMBps": None, "diskWriteMBps": None,
    "networkUploadMBps": None, "networkDownloadMBps": None,
}
LAST_TELEMETRY = 0.0
LAST_SENSOR = 0.0
HISTORY_RECORDER = None
LIVE_OPTIONAL_FIELDS = SENSOR_FIELDS + RATE_FIELDS + (
    "gpuTemp", "gpuUsage", "gpuPowerWatts", "gpuFanPercent", "vramUsedGB", "vramTotalGB", "gpuSource", "networkInterface", "fps", "fpsSource",
)


def load_token_file(path):
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    token = secrets.token_urlsafe(32)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation and private permissions on platforms that support them.
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as output:
            output.write(token + "\n")
    except FileExistsError:
        token = path.read_text(encoding="utf-8").strip()
    return token


def load_api_token(path=TOKEN_PATH):
    token = os.getenv("ORBIT_API_TOKEN", "").strip() or load_token_file(path)
    if len(token) < 24 or token == "endspec-secret-token":
        raise RuntimeError("Orbit token must contain at least 24 characters. Remove .orbit-token to generate a new token.")
    return token


def load_widget_token(path=WIDGET_TOKEN_PATH):
    token = load_token_file(path)
    if len(token) < 24 or token == API_TOKEN:
        raise RuntimeError("Orbit widget token must be a separate secret of at least 24 characters. Remove .orbit-widget-token to regenerate it.")
    return token


def authorized(authorization):
    return bool(API_TOKEN and isinstance(authorization, str)
                and hmac.compare_digest(authorization, f"Bearer {API_TOKEN}"))


def verify_token(authorization: str = Header(None)):
    if not authorized(authorization):
        raise HTTPException(status_code=401, detail="Invalid Orbit token", headers={"WWW-Authenticate": "Bearer"})


def require_windows():
    if os.name != "nt":
        raise HTTPException(status_code=501, detail="PC controls require Windows")


@contextmanager
def endpoint_volume():
    if not HAS_PYCAW or os.name != "nt":
        raise RuntimeError("Windows audio control is unavailable")
    comtypes.CoInitialize()
    try:
        device = AudioUtilities.GetSpeakers()
        volume = getattr(device, "EndpointVolume", None)
        if volume is None:
            # Older pycaw releases returned an IMMDevice without EndpointVolume.
            from pycaw.pycaw import IAudioEndpointVolume
            interface = device.Activate(IAudioEndpointVolume._iid_, comtypes.CLSCTX_ALL, None)
            volume = ctypes.cast(interface, ctypes.POINTER(IAudioEndpointVolume))
        yield volume
    finally:
        comtypes.CoUninitialize()


def audio_metrics():
    try:
        with endpoint_volume() as volume:
            return {"volume": round(volume.GetMasterVolumeLevelScalar() * 100, 1),
                    "isMuted": bool(volume.GetMute()), "volumeAvailable": True}
    except Exception:
        return {"volume": 0.0, "isMuted": False, "volumeAvailable": False}


def inventory_worker():
    global SPECS
    try:
        specs = collect_specs()
        with STATE_LOCK:
            SPECS = specs
            STATE["cpuName"] = specs["cpu"]["name"] or "Unavailable"
            STATE["motherboard"] = " ".join(filter(None, [specs["motherboard"]["manufacturer"], specs["motherboard"]["model"]])) or "Unavailable"
            STATE["gpuName"] = next((gpu["name"] for gpu in specs["gpus"] if gpu["name"]), "Unavailable")
    except Exception:
        LOGGER.exception("Hardware inventory failed; basic inventory remains available")


def sensor_worker():
    global LAST_SENSOR
    while not STOP_EVENT.is_set():
        try:
            sensors = sensor_metrics()
            with STATE_LOCK:
                # Sensor polling never overwrites newer NVIDIA readings.
                STATE.update({key: sensors.get(key) for key in SENSOR_FIELDS + ("sensorSource", "sensorStatus")})
                SENSOR_GPU_CACHE.clear()
                SENSOR_GPU_CACHE.update({key: sensors.get(key) for key in GPU_SENSOR_FIELDS})
                SENSOR_GPU_CACHE["gpuName"] = sensors.get("gpuSensorName")
                SENSOR_GPU_CACHE["gpuSource"] = sensors.get("gpuSensorSource") or sensors.get("sensorSource")
                LAST_SENSOR = time.monotonic()
        except Exception:
            with STATE_LOCK:
                STATE.update(dict.fromkeys(SENSOR_FIELDS))
                STATE["sensorSource"] = None
                STATE["sensorStatus"] = "Hardware sensors unavailable. Start MSI Afterburner and enable Monitoring, or use LibreHardwareMonitor with its local web server on port 8085."
                SENSOR_GPU_CACHE.clear()
        STOP_EVENT.wait(5)


def select_gpu_metrics(nvidia, sensor_cache, sensor_age):
    """Keep one adapter/source per sample, preferring the driver's NVIDIA data."""
    result = dict.fromkeys(GPU_SENSOR_FIELDS + ("gpuSource",))
    if nvidia:
        result.update({key: value for key, value in nvidia[0].items() if key != "driverVersion"})
        result["gpuSource"] = "NVIDIA SMI"
    elif sensor_age <= 15 and any(sensor_cache.get(key) is not None for key in GPU_SENSOR_FIELDS):
        result.update({key: sensor_cache.get(key) for key in GPU_SENSOR_FIELDS})
        result["gpuName"] = sensor_cache.get("gpuName") or "GPU · hardware monitor"
        result["gpuSource"] = sensor_cache.get("gpuSource") or "Hardware monitor"
    return result


def telemetry_worker():
    global LAST_TELEMETRY
    psutil.cpu_percent(interval=None)
    rates = IOCounterRates()
    while not STOP_EVENT.wait(1):
        try:
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage(os.getenv("SystemDrive", "C:") + "\\" if os.name == "nt" else "/")
            update = {
                "cpuUsage": round(psutil.cpu_percent(interval=None), 1),
                "ramUsedGB": round(memory.used / 1024 ** 3, 2), "ramTotalGB": round(memory.total / 1024 ** 3, 2),
                # Legacy field names; these describe the system volume, not an assumed SSD.
                "ssdUsedTB": round(disk.used / 1024 ** 4, 3), "ssdTotalTB": round(disk.total / 1024 ** 4, 3),
                "uptimeSeconds": max(0, int(time.time() - psutil.boot_time())),
                "gpuTemp": None, "gpuUsage": None, "gpuPowerWatts": None,
                "vramUsedGB": None, "vramTotalGB": None, "gpuFanPercent": None,
            }
            update.update(io_metrics(rates))
            gpus = nvidia_metrics()
            with STATE_LOCK:
                sensor_cache = copy.deepcopy(SENSOR_GPU_CACHE)
                sensor_age = time.monotonic() - LAST_SENSOR
            update.update(select_gpu_metrics(gpus, sensor_cache, sensor_age))
            game = detect_game()
            update.update(activeGame=game["name"] if game else None,
                          activeGameProcess=game["process"] if game else None)
            update.update(read_fps(game))
            update.update(audio_metrics())
            update.update(telemetryAvailable=True, lastUpdated=timestamp())
            with STATE_LOCK:
                STATE.update(update)
                LAST_TELEMETRY = time.monotonic()
            record_history(status_snapshot())
        except Exception:
            LOGGER.exception("Telemetry sample failed")
            with STATE_LOCK:
                STATE["telemetryAvailable"] = False
                for key in LIVE_OPTIONAL_FIELDS:
                    STATE[key] = None
            record_history({"telemetryAvailable": False})


def record_history(metrics):
    recorder = HISTORY_RECORDER
    if recorder is not None:
        try:
            recorder.record_sample(metrics)
        except Exception:
            LOGGER.exception("Could not save this session sample")


@asynccontextmanager
async def lifespan(application):
    global API_TOKEN, WIDGET_TOKEN, SPECS, HISTORY_RECORDER
    API_TOKEN = load_api_token()
    WIDGET_TOKEN = load_widget_token()
    SPECS = basic_specs()
    HISTORY_RECORDER = SessionRecorder()
    STOP_EVENT.clear()
    threads = [threading.Thread(target=worker, daemon=True) for worker in (inventory_worker, telemetry_worker, sensor_worker)]
    for thread in threads:
        thread.start()
    if ADVERTISEMENT is not None:
        try:
            await asyncio.to_thread(ADVERTISEMENT.start)
        except Exception:
            LOGGER.exception("Automatic discovery unavailable; manual pairing is still available")
    yield
    STOP_EVENT.set()
    if PAIRING_MANAGER is not None:
        PAIRING_MANAGER.close()
    if ADVERTISEMENT is not None:
        await asyncio.to_thread(ADVERTISEMENT.close)
    for thread in threads:
        await asyncio.to_thread(thread.join, 5)
    recorder, HISTORY_RECORDER = HISTORY_RECORDER, None
    if recorder is not None:
        recorder.close()


app = FastAPI(title="Orbit PC Companion Agent", version=AGENT_VERSION, lifespan=lifespan,
              docs_url=None, redoc_url=None, openapi_url=None)
app.include_router(create_files_router(verify_token))
app.include_router(create_desktop_router(verify_token))
app.include_router(create_history_router(verify_token, lambda: HISTORY_RECORDER))
app.include_router(create_pairing_router(lambda: PAIRING_MANAGER))


@app.get("/api/discover")
def discover():
    # Public bootstrap hints only. Secrets and network configuration require PIN proof.
    return {"service": "orbit-agent", "version": 3, "agentVersion": AGENT_VERSION,
            "name": socket.gethostname(), "securePort": SECURE_PORT,
            "fingerprint": CERTIFICATE_FINGERPRINT, "pairingAvailable": PAIRING_MANAGER is not None}


def get_local_network_details(preferred_ip=None):
    """Prefer the routed interface and return only an actual adapter's MAC."""
    routed_ip = None
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("1.1.1.1", 80))  # Route selection; no packet is sent.
            routed_ip = probe.getsockname()[0]
    except OSError:
        pass
    candidates = []
    stats = psutil.net_if_stats()
    for interface, addresses in psutil.net_if_addrs().items():
        if interface in stats and not stats[interface].isup:
            continue
        for address in addresses:
            if address.family != socket.AF_INET or address.address.startswith("127."):
                continue
            mac = next((a.address.replace("-", ":").upper() for a in addresses if a.family == psutil.AF_LINK), "")
            mask = address.netmask or ""
            try:
                broadcast = str(ipaddress.IPv4Network(f"{address.address}/{mask}", strict=False).broadcast_address) if mask else ""
            except ValueError:
                broadcast = ""
            candidates.append({"hostname": socket.gethostname(), "ipAddress": address.address,
                               "subnetMask": mask, "broadcastAddress": broadcast, "macAddress": mac,
                               "agentPort": AGENT_PORT})
    return next((n for n in candidates if n["ipAddress"] == preferred_ip), None) or next((n for n in candidates if n["ipAddress"] == routed_ip), candidates[0] if candidates else {
        "hostname": socket.gethostname(), "ipAddress": "", "subnetMask": "", "broadcastAddress": "",
        "macAddress": "", "agentPort": AGENT_PORT})


def pairing_payload(host):
    return {**get_local_network_details(host), "securePort": SECURE_PORT,
            "apiToken": API_TOKEN, "widgetToken": WIDGET_TOKEN, "agentVersion": AGENT_VERSION}


@app.get("/api/network-info")
def api_network_info(request: Request, authorization: str = Header(None)):
    verify_token(authorization)
    return get_local_network_details((request.scope.get("server") or (None,))[0])


@app.get("/api/specs")
def get_specs(authorization: str = Header(None)):
    verify_token(authorization)
    with STATE_LOCK:
        return copy.deepcopy(SPECS)


def status_snapshot():
    with STATE_LOCK:
        result = copy.deepcopy(STATE)
        if time.monotonic() - LAST_TELEMETRY > 10:
            result["telemetryAvailable"] = False
            for key in LIVE_OPTIONAL_FIELDS:
                result[key] = None
        if time.monotonic() - LAST_SENSOR > 15:
            for key in SENSOR_FIELDS:
                result[key] = None
            result["sensorSource"] = None
            result["sensorStatus"] = "Hardware sensor readings expired; waiting for a fresh sample from the PC sensor monitor."
            # Main telemetry may still be fresh while its hardware-monitor cache
            # ages out. NVIDIA readings have an independent, current source.
            if result.get("gpuSource") != "NVIDIA SMI":
                for key in GPU_SENSOR_FIELDS + ("gpuSource",):
                    result[key] = None
        return result


@app.get("/api/status")
def get_status(authorization: str = Header(None)):
    verify_token(authorization)
    return status_snapshot()


@app.post("/api/widget/pairing")
def widget_pairing(authorization: str = Header(None)):
    verify_token(authorization)
    return {"token": WIDGET_TOKEN}


@app.get("/api/widget/status")
def widget_status(authorization: str = Header(None)):
    if not WIDGET_TOKEN or not isinstance(authorization, str) or not hmac.compare_digest(authorization, f"Bearer {WIDGET_TOKEN}"):
        raise HTTPException(status_code=401, detail="Invalid Orbit widget token", headers={"WWW-Authenticate": "Bearer"})
    status = status_snapshot()
    available = bool(status.get("telemetryAvailable"))
    sample_time = None
    try:
        parsed = datetime.fromisoformat(status.get("lastUpdated") or "")
        if parsed.tzinfo is not None:
            sample_time = parsed.timestamp()
    except (ValueError, TypeError):
        pass
    result = {"pc_name": status.get("hostname") or "PC", "timestamp": sample_time,
              "telemetry_available": available}
    mapping = {"cpu_usage": "cpuUsage", "gpu_usage": "gpuUsage", "cpu_temp": "cpuTemp", "gpu_temp": "gpuTemp",
               "vram_used": "vramUsedGB", "vram_total": "vramTotalGB", "cpu_power": "cpuPowerWatts",
               "gpu_power": "gpuPowerWatts", "cpu_clock": "cpuClockMHz", "cpu_fan": "cpuFanRPM",
               "gpu_fan": "gpuFanPercent", "coolant_temp": "liquidTemp", "disk_read": "diskReadMBps",
               "disk_write": "diskWriteMBps", "network_download": "networkDownloadMBps",
               "network_upload": "networkUploadMBps", "fps": "fps", "game_name": "activeGame"}
    result.update({key: status.get(source) if available else None for key, source in mapping.items()})
    total = status.get("ramTotalGB") or 0
    result["ram_usage"] = round(status["ramUsedGB"] / total * 100, 1) if available and total > 0 else None
    return result


@app.get("/api/processes")
def list_processes(authorization: str = Header(None)):
    verify_token(authorization)
    require_windows()
    return collect_processes()


@app.post("/api/processes/{pid}/terminate")
def end_process(pid: int, expectedCreateTime: float = Query(..., gt=0), force: bool = False,
                authorization: str = Header(None)):
    verify_token(authorization)
    require_windows()
    if not math.isfinite(expectedCreateTime):
        raise HTTPException(status_code=422, detail="A valid process creation time is required")
    try:
        return terminate_process(pid, expectedCreateTime, force)
    except ProcessLookupError as error:
        raise HTTPException(status_code=409, detail=str(error)) from error
    except PermissionError as error:
        raise HTTPException(status_code=403, detail=str(error)) from error
    except ValueError as error:
        raise HTTPException(status_code=422, detail=str(error)) from error
    except psutil.Error as error:
        raise HTTPException(status_code=503, detail="Windows could not complete the process request") from error


@app.post("/api/volume")
def api_set_volume(level: int, authorization: str = Header(None)):
    verify_token(authorization)
    require_windows()
    if not 0 <= level <= 100:
        raise HTTPException(status_code=422, detail="Volume must be between 0 and 100")
    try:
        with endpoint_volume() as volume:
            volume.SetMasterVolumeLevelScalar(level / 100, None)
        measured = audio_metrics()
        with STATE_LOCK:
            STATE.update(measured)
        return {"status": "ok", **measured}
    except Exception as error:
        raise HTTPException(status_code=503, detail="Windows audio control is unavailable") from error


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


def tap_key(vk):
    ctypes.windll.user32.keybd_event(vk, 0, 0, 0)
    ctypes.windll.user32.keybd_event(vk, 0, 2, 0)


@app.post("/api/input/mouse")
def mouse_input(dx: int = 0, dy: int = 0, click: str = "", scroll: int = 0, authorization: str = Header(None)):
    verify_token(authorization)
    require_windows()
    if click not in {"", "left", "double", "right"} or max(abs(dx), abs(dy)) > 10000 or abs(scroll) > 100:
        raise HTTPException(status_code=422, detail="Invalid mouse input")
    u32 = ctypes.windll.user32
    if dx or dy:
        point = POINT()
        if not u32.GetCursorPos(ctypes.byref(point)) or not u32.SetCursorPos(point.x + dx, point.y + dy):
            raise HTTPException(status_code=503, detail="Windows could not move the cursor")
    for _ in range(2 if click == "double" else 1):
        if click in {"left", "double"}:
            u32.mouse_event(0x0002, 0, 0, 0, 0)
            u32.mouse_event(0x0004, 0, 0, 0, 0)
        elif click == "right":
            u32.mouse_event(0x0008, 0, 0, 0, 0)
            u32.mouse_event(0x0010, 0, 0, 0, 0)
    if scroll:
        u32.mouse_event(0x0800, 0, 0, scroll * 120, 0)
    return {"status": "sent"}


@app.post("/api/input/keyboard")
def keyboard_input(text: str = "", key: str = "", authorization: str = Header(None)):
    verify_token(authorization)
    require_windows()
    special = {"ENTER": 0x0D, "BACKSPACE": 0x08, "SPACE": 0x20, "ESC": 0x1B, "WIN": 0x5B, "TAB": 0x09}
    if (key and key.upper() not in special) or len(text) > 1000:
        raise HTTPException(status_code=422, detail="Unsupported key or text too long")
    u32 = ctypes.windll.user32
    u32.VkKeyScanW.argtypes = [ctypes.c_wchar]
    u32.VkKeyScanW.restype = ctypes.c_short
    codes = [u32.VkKeyScanW(char) if ord(char) <= 0xFFFF else -1 for char in text]
    if -1 in codes:
        raise HTTPException(status_code=422, detail="Some characters are not available in the PC keyboard layout")
    if key:
        tap_key(special[key.upper()])
    for code in codes:
        modifiers = [vk for mask, vk in ((1, 0x10), (2, 0x11), (4, 0x12)) if (code >> 8) & mask]
        for modifier in modifiers:
            u32.keybd_event(modifier, 0, 0, 0)
        tap_key(code & 0xFF)
        for modifier in reversed(modifiers):
            u32.keybd_event(modifier, 0, 2, 0)
    return {"status": "sent"}


@app.post("/api/input/gamepad")
def gamepad_input(button: str, authorization: str = Header(None)):
    verify_token(authorization)
    require_windows()
    keymap = {"A": 0x20, "B": 0x1B, "X": 0x45, "Y": 0x52, "UP": 0x57, "DOWN": 0x53, "LEFT": 0x41, "RIGHT": 0x44}
    if button.upper() not in keymap:
        raise HTTPException(status_code=422, detail="Unsupported gamepad button")
    tap_key(keymap[button.upper()])
    return {"status": "sent", "mode": "keyboard_mapping"}


@app.post("/api/action/{action_name}")
def execute_action(action_name: str, authorization: str = Header(None)):
    verify_token(authorization)
    actions = {"lock", "sleep", "restart", "shutdown", "mute", "media_play_pause", "media_next", "media_prev", "toggle_hdr", "restore_display", "kill_game"}
    if action_name not in actions:
        raise HTTPException(status_code=404, detail="Unknown PC action")
    require_windows()
    u32 = ctypes.windll.user32
    try:
        if action_name == "lock":
            if not u32.LockWorkStation():
                raise OSError("LockWorkStation failed")
        elif action_name == "sleep":
            # Do not force suspension; let Windows honor its power policy.
            if not ctypes.windll.powrprof.SetSuspendState(0, 0, 0):
                raise OSError("SetSuspendState failed")
        elif action_name in {"restart", "shutdown"}:
            subprocess.run(["shutdown", "/r" if action_name == "restart" else "/s", "/t", "3"], check=True,
                           timeout=5, capture_output=True, creationflags=0x08000000)
        elif action_name in {"mute", "media_play_pause", "media_next", "media_prev"}:
            tap_key({"mute": 0xAD, "media_play_pause": 0xB3, "media_next": 0xB0, "media_prev": 0xB1}[action_name])
        elif action_name == "toggle_hdr":
            u32.keybd_event(0x5B, 0, 0, 0)
            u32.keybd_event(0x12, 0, 0, 0)
            tap_key(0x42)
            u32.keybd_event(0x12, 0, 2, 0)
            u32.keybd_event(0x5B, 0, 2, 0)
            # Shortcut delivery cannot verify HDR state; hdrEnabled remains null.
        elif action_name == "restore_display":
            subprocess.Popen(["DisplaySwitch.exe", "/extend"], creationflags=0x08000000)
        elif action_name == "kill_game":
            game = detect_game()
            if not game or not game["foreground"]:
                raise HTTPException(status_code=409, detail="Bring the detected game to the foreground before closing it")
            # Close only the verified foreground game, never an arbitrary active window.
            handle = u32.GetForegroundWindow()
            pid = ctypes.c_ulong()
            u32.GetWindowThreadProcessId(handle, ctypes.byref(pid))
            if pid.value != game["pid"]:
                raise HTTPException(status_code=409, detail="The foreground application changed")
            u32.PostMessageW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_size_t, ctypes.c_ssize_t]
            if not u32.PostMessageW(handle, 0x0010, 0, 0):
                raise OSError("Windows rejected close request")
    except (OSError, subprocess.SubprocessError) as error:
        raise HTTPException(status_code=503, detail="Windows could not execute this action") from error
    return {"status": "sent", "executed": action_name}


def sunshine_entries():
    for path in SUNSHINE_APPS_PATHS:
        if path.is_file():
            try:
                data = json.loads(path.read_text(encoding="utf-8-sig"))
                entries = data.get("apps", [])
                if not isinstance(entries, list):
                    raise ValueError("Invalid apps list")
                return [entry for entry in entries if isinstance(entry, dict)]
            except (OSError, ValueError, AttributeError) as error:
                raise HTTPException(status_code=503, detail="Sunshine apps configuration is unreadable") from error
    return []


@app.get("/api/sunshine/apps")
def get_sunshine_apps(authorization: str = Header(None)):
    verify_token(authorization)
    return [{"id": str(index + 1), "title": entry.get("name") or f"Sunshine App {index + 1}",
             "genre": "Sunshine library", "iconSymbol": "gamecontroller.fill", "accentHex": "#57C8FF",
             "isFavorite": False} for index, entry in enumerate(sunshine_entries())]


@app.post("/api/sunshine/launch")
def launch_sunshine_app(app: str, authorization: str = Header(None)):
    verify_token(authorization)
    require_windows()
    for entry in sunshine_entries():
        if str(entry.get("name", "")).casefold() == app.casefold():
            detached = entry.get("detached") or []
            command = entry.get("cmd") or (detached[0] if isinstance(detached, list) and detached else None)
            if not isinstance(command, str) or not command.strip():
                raise HTTPException(status_code=409, detail="This Sunshine entry has no direct launch command. Open it in Moonlight.")
            try:
                # Only commands from the user's local Sunshine configuration are accepted.
                subprocess.Popen(command, shell=True, cwd=entry.get("working-dir") or None,
                                 creationflags=0x08000000)
            except OSError as error:
                raise HTTPException(status_code=503, detail="Could not start the configured application") from error
            return {"status": "launch_requested", "app": app}
    raise HTTPException(status_code=404, detail="Application was not found in Sunshine")


@app.websocket("/ws/stream")
async def websocket_video_stream(websocket: WebSocket):
    if not authorized(websocket.headers.get("authorization")):
        await websocket.close(code=1008)
        return
    await websocket.accept()
    if not HAS_SCREEN_CAPTURE:
        await websocket.close(code=1011, reason="Screen capture dependencies are unavailable")
        return
    try:
        with mss.mss() as capture:
            if len(capture.monitors) < 2:
                await websocket.close(code=1011, reason="No display is available")
                return
            monitor = capture.monitors[1]
            while True:
                raw = capture.grab(monitor)
                image = Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")
                image.thumbnail((1280, 720))
                buffer = io.BytesIO()
                image.save(buffer, format="JPEG", quality=68)
                await websocket.send_bytes(buffer.getvalue())
                await asyncio.sleep(0.05)
    except WebSocketDisconnect:
        pass
    except Exception:
        LOGGER.exception("Screen preview failed")
        try:
            await websocket.close(code=1011, reason="Screen preview failed")
        except RuntimeError:
            pass


@app.get("/api/update/check")
def api_check_for_updates(authorization: str = Header(None)):
    verify_token(authorization)
    from orbit_updater import check_for_updates
    try:
        return check_for_updates(AGENT_VERSION)
    except Exception as error:
        raise HTTPException(status_code=503, detail=str(error)) from error


@app.post("/api/update/apply")
def api_apply_update(authorization: str = Header(None)):
    verify_token(authorization)
    from orbit_updater import check_for_updates, download_and_apply_update
    try:
        info = check_for_updates(AGENT_VERSION)
    except Exception as error:
        raise HTTPException(status_code=503, detail=str(error)) from error
    if not info.get("updateAvailable"):
        return {"status": "up_to_date", "currentVersion": AGENT_VERSION, "latestVersion": info.get("latestVersion")}
    download_url = info.get("downloadUrl")
    if not download_url:
        raise HTTPException(status_code=409, detail="No downloadable update archive is available for this release")
    try:
        updated = download_and_apply_update(download_url)
    except Exception as error:
        raise HTTPException(status_code=503, detail=f"Could not apply update: {error}") from error
    return {
        "status": "updated",
        "currentVersion": AGENT_VERSION,
        "latestVersion": info.get("latestVersion"),
        "updatedFiles": updated,
    }


def tray_status_snapshot():
    network = get_local_network_details()
    with STATE_LOCK:
        active_game = STATE.get("activeGame")
    return {
        "agentVersion": AGENT_VERSION,
        "hostname": network.get("hostname") or socket.gethostname(),
        "ipAddress": network.get("ipAddress") or "",
        "agentPort": AGENT_PORT,
        "securePort": SECURE_PORT,
        "fingerprint": CERTIFICATE_FINGERPRINT,
        "activeGame": active_game,
    }


def _acquire_single_instance_mutex():
    if os.name != "nt":
        return None
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
        kernel32.CreateMutexW.restype = ctypes.c_void_p
        name = f"Local\\OrbitPCCompanion_{AGENT_PORT}_{SECURE_PORT}"
        handle = kernel32.CreateMutexW(None, 1, name)
        if handle and ctypes.get_last_error() == 183:  # ERROR_ALREADY_EXISTS
            kernel32.CloseHandle(ctypes.c_void_p(handle))
            return False
        return handle
    except Exception:
        return None


if __name__ == "__main__":
    import sys
    from orbit_tls import ensure_tls_identity, serve_both
    from orbit_tray import OrbitTrayIcon, StartupManager, ensure_background_stdio

    os.chdir(_RUNTIME_DIR)
    args = {arg.strip().lower() for arg in sys.argv[1:]}
    if "--enable-startup" in args:
        StartupManager().set_enabled(True)
        raise SystemExit(0)
    if "--disable-startup" in args:
        StartupManager().set_enabled(False)
        raise SystemExit(0)
    if "--check-updates" in args:
        tray = OrbitTrayIcon(status_provider=tray_status_snapshot, on_stop=lambda: None)
        result = tray.perform_update_check()
        print(json.dumps(result, indent=2))
        raise SystemExit(0)

    log_file = ensure_background_stdio()
    mutex = _acquire_single_instance_mutex()
    if mutex is False:
        if os.name == "nt" and "--background" not in args:
            ctypes.windll.user32.MessageBoxW(
                None,
                "Orbit PC Companion is already running in the system tray (bottom-right notification area).\n\n"
                "Click the Orbit icon in the taskbar corner to view connection details, check for updates, toggle Windows startup, or stop the companion.",
                "Orbit PC Companion",
                0x00040040,
            )
        raise SystemExit(0)

    try:
        API_TOKEN = load_api_token()
        certificate, private_key, fingerprint = ensure_tls_identity()
    except Exception as startup_error:
        if os.name == "nt" and ("--background" in args or "--tray" in args):
            ctypes.windll.user32.MessageBoxW(
                None,
                f"Orbit PC Companion could not start:\n\n{startup_error}",
                "Orbit PC Companion · Startup Error",
                0x00040010,
            )
        raise

    CERTIFICATE_FINGERPRINT = fingerprint
    PAIRING_MANAGER = PairingManager(fingerprint, pairing_payload)
    ADVERTISEMENT = OrbitAdvertisement(SECURE_PORT, fingerprint, AGENT_VERSION)
    network = get_local_network_details()
    print(f"Orbit PC Companion {AGENT_VERSION} · port {AGENT_PORT}")
    print(f"PC IP: {network['ipAddress'] or 'No active LAN adapter'}")
    print("In Orbit on iPhone, choose Find my PC. A one-use code will appear here and in a Windows dialog.")
    print(f"Advanced manual pairing token: {API_TOKEN}")
    print(f"Encrypted connection port: {SECURE_PORT}")
    print(f"Certificate SHA-256 (manual setup only): {fingerprint}")
    print("Keep this token private. Use a trusted home network or VPN; do not port-forward this agent.")

    STOP_EVENT.clear()
    tray = OrbitTrayIcon(
        status_provider=tray_status_snapshot,
        on_stop=STOP_EVENT.set,
        token_provider=lambda: API_TOKEN,
        log_path=log_file,
        notify_on_start=("--tray" in args),
    )
    tray.start()
    if ("--background" in args or "--tray" in args) and "--console" not in args:
        tray.set_console_visible(False)
    try:
        asyncio.run(serve_both(
            app,
            os.getenv("ORBIT_HOST", "0.0.0.0"),
            AGENT_PORT,
            SECURE_PORT,
            certificate,
            private_key,
            stop_event=STOP_EVENT,
        ))
    except KeyboardInterrupt:
        pass
    finally:
        STOP_EVENT.set()
        tray.close()
